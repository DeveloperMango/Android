Simple Launcher
==============

An example custom launcher for Android, read more here: http://arnab.ch/blog/2013/08/how-to-write-custom-launcher-app-in-android/

-------
MIT License. Copyright 2016 Arnab Chakraborty. http://arnab.ch
