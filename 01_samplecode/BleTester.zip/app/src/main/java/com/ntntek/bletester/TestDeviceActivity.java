package com.ntntek.bletester;


import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ntntek.Scalable.ScalableLayout;
import com.ntntek.Util.Debug;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public class TestDeviceActivity extends Activity {
    private final static String TAG = TestDeviceActivity.class.getSimpleName();

    private String mDeviceName, mDeviceAddress, mRSSI;
    private String mLogFilePath;

    byte mMajorVer, mMinorVer, mRevisionVer;

    ArrayList<ArrayList<String>> mLogData_ALL=null;
    ArrayList<String> mLogData_BT=null;
    ArrayList<String> mLogData_BIA=null;
    ArrayList<String> mLogData_BAT=null;
    ArrayList<String> mLogData_UV=null;
    ArrayList<String> mLogData_LUX=null;
    ArrayList<String> mLogData_HUM=null;
    ArrayList<String> mLogData_TEM=null;
    ArrayList<String> mLogData_ACC=null;
    ArrayList<String> mLogData_SF=null;
    ArrayList<String> mLogData_LED=null;
    ArrayList<String> mLogData_VIB=null;
    ArrayList<String> mLogData_KEY=null;

    ProgressDialog mDialog; // 화면 진입시 서비스 연결중을 나타내는 프로그레스바

    TextView mMacAddress, mFirmwareVer;
    TextView mBluetoothValue, mBluetoothResult; // RSSI
    TextView mSkinValue, mSkinResult;               // skin
    TextView mBatteryValue, mBatteryResult; // battery
    TextView mUVValue, mUVResult;           // uv
    TextView mLUXValue, mLUXResult;        // lux
    TextView mHUMValue, mHUMResult;     // humidity
    TextView mTEMPValue, mTEMPResult;   // temperature
    TextView mACCELValue, mACCELResult; // accelerator
    TextView mSFResult;     // serial flash
    TextView mButtonInputResult;
    RadioButton mLEDok, mLEDfail;
    RadioButton mVIBok, mVIBfail;
    EditText mSkin_freq;
    EditText mUV_ref, mUV_range;
    EditText mLUX_ref, mLUX_range;
    EditText mHUM_ref, mHUM_range;
    EditText mTEMP_ref, mTEMP_range;

    private Button mReturnButton;
    private LinearLayout mChartLayout;
    private ScalableLayout mScalableLayout;
    private boolean isSkinValueClicked = false;
    private ProgressDialog mLoading;

    int mSkinData[]=new int[ProtocolConstants.SKIN_DATA_SIZE*2];
    int mSkinDataIndex=0;
    int mSkinReturnValue_Freq;

    private BluetoothLeService mBluetoothLeService;
    private ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics =
            new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
    private boolean mConnected = false;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private BluetoothGattCharacteristic mWriteCharacteristic;

    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";

    private Context mContext;

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
            Log.i("KILEE", "onServiceConnected()");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        getActionBar().hide();
        setContentView(R.layout.activity_testdevice);

        // always turns on
        int flags = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON;
        getWindow().addFlags(flags);

        initializeLogData();

        mNotifyCharacteristic=null;
        mWriteCharacteristic=null;

        final Intent intent = getIntent();
        mDeviceName = intent.getStringExtra(ProtocolConstants.EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(ProtocolConstants.EXTRAS_DEVICE_ADDRESS);
        mRSSI = intent.getStringExtra(ProtocolConstants.EXTRAS_DEVICE_RSSI);
        mLogData_BT.add("OK");
        mLogData_BT.add(mRSSI);

        mSkin_freq = (EditText) findViewById(R.id.skin_freq_value);
        mUV_ref = (EditText) findViewById(R.id.uv_ref_value);
        mUV_range = (EditText) findViewById(R.id.uv_range_value);
        mLUX_ref = (EditText) findViewById(R.id.lux_ref_value);
        mLUX_range = (EditText) findViewById(R.id.lux_range_value);
        mHUM_ref = (EditText) findViewById(R.id.hum_ref_value);
        mHUM_range = (EditText) findViewById(R.id.hum_range_value);
        mTEMP_ref = (EditText) findViewById(R.id.temp_ref_value);
        mTEMP_range = (EditText) findViewById(R.id.temp_range_value);

        mMacAddress = (TextView) findViewById(R.id.mac_value);
        mMacAddress.setText(mDeviceAddress);
        mFirmwareVer = (TextView) findViewById(R.id.firmware_ver_value);
        mBluetoothValue = (TextView) findViewById(R.id.bluetooth_value);
        mBluetoothResult = (TextView) findViewById(R.id.bluetooth_result);

        mSkinValue = (TextView) findViewById(R.id.skin_value);
        mSkinValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Debug.logd(new Exception(), "mSkinValue is Clicked...");

                isSkinValueClicked = true;

                // 키보드 내리기
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                mScalableLayout.setVisibility(View.GONE);
                mChartLayout.setVisibility(View.VISIBLE);
                mLoading = ProgressDialog.show(mContext, "", "Please wait...", true);

                final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_SKIN_1ST);
                sendBroadcast(nextIntent);
            }
        });
        mSkinResult = (TextView) findViewById(R.id.skin_result);

        mBatteryValue = (TextView) findViewById(R.id.battery_value);
        mBatteryResult = (TextView) findViewById(R.id.battery_result);

        mUVValue = (TextView) findViewById(R.id.uv_value);
        mUVResult = (TextView) findViewById(R.id.uv_result);

        mLUXValue = (TextView) findViewById(R.id.lux_value);
        mLUXResult = (TextView) findViewById(R.id.lux_result);

        mHUMValue = (TextView) findViewById(R.id.hum_value);
        mHUMResult = (TextView) findViewById(R.id.hum_result);

        mTEMPValue = (TextView) findViewById(R.id.tem_value);
        mTEMPResult = (TextView) findViewById(R.id.tem_result);

        mACCELValue = (TextView) findViewById(R.id.accel_value);
        mACCELResult = (TextView) findViewById(R.id.accel_result);

        mSFResult = (TextView) findViewById(R.id.serialflash_result);

        mButtonInputResult = (TextView) findViewById(R.id.buttoninput_result);

        mLEDok = (RadioButton) findViewById(R.id.led_ok_radio);
        mLEDfail = (RadioButton) findViewById(R.id.led_fail_radio);

        mVIBok = (RadioButton) findViewById(R.id.vib_ok_radio);
        mVIBfail = (RadioButton) findViewById(R.id.vib_fail_radio);

        mScalableLayout = (ScalableLayout) findViewById(R.id.mac_layout);

        RelativeLayout root_layout=(RelativeLayout)findViewById(R.id.root_layout);
        root_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   // 레이아웃의 키보드 내리기
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        });
        
        mChartLayout = (LinearLayout) findViewById(R.id.chart_layout);
        mReturnButton = (Button) findViewById(R.id.return_button);

        mReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Debug.logd(new Exception(), "mReturnButton is Clicked...");

                mScalableLayout.setVisibility(View.VISIBLE);
                mChartLayout.setVisibility(View.GONE);
            }
        });
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);

        getRefPreference();

        mDialog=ProgressDialog.show(this, "", "Connecting to BLE Service.", true);
    }

    public void getRefPreference() {
        SharedPreferences prefs = getSharedPreferences(ProtocolConstants.SENSOR_PREF, MODE_PRIVATE);
        String skinPref = prefs.getString(ProtocolConstants.KEY_SKIN_REF, mSkin_freq.getText().toString());
        String uv_valuePref = prefs.getString(ProtocolConstants.KEY_UV_REF, mUV_ref.getText().toString());
        String uv_rangePref = prefs.getString(ProtocolConstants.KEY_UV_RANGE, mUV_range.getText().toString());
        String lux_valuePref = prefs.getString(ProtocolConstants.KEY_LUX_REF, mLUX_ref.getText().toString());
        String lux_rangePref = prefs.getString(ProtocolConstants.KEY_LUX_RANGE, mLUX_range.getText().toString());
        String hum_valuePref = prefs.getString(ProtocolConstants.KEY_HUM_REF, mHUM_ref.getText().toString());
        String hum_rangePref = prefs.getString(ProtocolConstants.KEY_HUM_RANGE, mHUM_range.getText().toString());
        String tem_valuePref = prefs.getString(ProtocolConstants.KEY_TEM_REF, mTEMP_ref.getText().toString());
        String tem_rangePref = prefs.getString(ProtocolConstants.KEY_TEM_RANGE, mTEMP_range.getText().toString());

        Log.i("KILEE", "skinPref : " + skinPref);
        Log.i("KILEE", "uv_valuePref : " + uv_valuePref);
        Log.i("KILEE", "uv_rangePref : " + uv_rangePref);
        Log.i("KILEE", "lux_valuePref : " + lux_valuePref);
        Log.i("KILEE", "lux_rangePref : " + lux_rangePref);
        Log.i("KILEE", "hum_valuePref : " + hum_valuePref);
        Log.i("KILEE", "hum_rangePref : " + hum_rangePref);
        Log.i("KILEE", "tem_valuePref : " + tem_valuePref);
        Log.i("KILEE", "tem_rangePref : " + tem_rangePref);

        mSkin_freq.setText(skinPref);
        mUV_ref.setText(uv_valuePref);        mUV_range.setText(uv_rangePref);
        mLUX_ref.setText(lux_valuePref);        mLUX_range.setText(lux_rangePref);
        mHUM_ref.setText(hum_valuePref);        mHUM_range.setText(hum_rangePref);
        mTEMP_ref.setText(tem_valuePref);        mTEMP_range.setText(tem_rangePref);
    }

    public void setRefPreferences() {
        SharedPreferences prefs = getSharedPreferences(ProtocolConstants.SENSOR_PREF, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(ProtocolConstants.KEY_SKIN_REF, mSkin_freq.getText().toString());
        editor.putString(ProtocolConstants.KEY_UV_REF, mUV_ref.getText().toString());
        editor.putString(ProtocolConstants.KEY_UV_RANGE, mUV_range.getText().toString());
        editor.putString(ProtocolConstants.KEY_LUX_REF, mLUX_ref.getText().toString());
        editor.putString(ProtocolConstants.KEY_LUX_RANGE, mLUX_range.getText().toString());
        editor.putString(ProtocolConstants.KEY_HUM_REF, mHUM_ref.getText().toString());
        editor.putString(ProtocolConstants.KEY_HUM_RANGE, mHUM_range.getText().toString());
        editor.putString(ProtocolConstants.KEY_TEM_REF, mTEMP_ref.getText().toString());
        editor.putString(ProtocolConstants.KEY_TEM_RANGE, mTEMP_range.getText().toString());
        editor.commit();
    }

    @Override
    public void onBackPressed() {
        setRefPreferences();
        mDialog.hide();
        mBluetoothLeService.disconnect();
        finish();
    }

    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.led_ok_radio:{
                mLogData_LED.add("OK");
                mLEDok.setChecked(true);                mLEDfail.setChecked(false);                break;
            }
            case R.id.led_fail_radio:{
                mLogData_LED.add("FAIL");
                mLEDok.setChecked(false);                mLEDfail.setChecked(true);                break;
            }
            case R.id.vib_ok_radio:{
                mLogData_VIB.add("OK");
                mVIBok.setChecked(true);                mVIBfail.setChecked(false);                break;
            }
            case R.id.vib_fail_radio:{
                mLogData_VIB.add("FAIL");
                mVIBok.setChecked(false);                mVIBfail.setChecked(true);                break;
            }

            case R.id.led_vib_start_button: {
                send_led_cmd();
                send_vib_cmd();
                break;
            }

            case R.id.poweroff_button: {
                setRefPreferences();
                make_and_save_logfile();
                send_poweroff_cmd();
                break;
            }

            case R.id.retry_button: {
                clear_and_retry();
                break;
            }
/*
            case R.id.settime_button: {
                byte[] value = new byte[5];
                long now = System.currentTimeMillis();
                now /= 1000;    // 초단위로 변경
                int now_int = (int) now;

                Log.i("KILEE", "now : " + now + " now_int : " + now_int);

                value[0]=TestCommand.SET_TIME_CMD;
                value[1]=(byte)(now&0xff);
                value[2]=(byte)((now&0xff00)>>8);
                value[3]=(byte)((now&0xff0000)>>16);
                value[4]=(byte)((now&0xff000000)>>24);
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
                break;
            }

            case R.id.gettime_button: {
                byte[] value = new byte[4];
                value[0]=TestCommand.GET_TIME_CMD;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
                break;
            }
            */
        }
    }

    void clear_and_retry() {
        isSkinValueClicked = false;
        mFirmwareVer.setText("");
        mBluetoothValue.setText("");
        mBluetoothResult.setText("");
        mSkinValue.setText("");
        mSkinResult.setText("");
        mBatteryValue.setText("");
        mBatteryResult.setText("");
        mUVValue.setText("");
        mUVResult.setText("");
        mLUXValue.setText("");
        mLUXResult.setText("");
        mHUMValue.setText("");
        mHUMResult.setText("");
        mTEMPValue.setText("");
        mTEMPResult.setText("");
        mACCELValue.setText("");
        mACCELResult.setText("");
        mSFResult.setText("");
        mButtonInputResult.setText("");
        mLEDok.setChecked(false);                mLEDfail.setChecked(false);
        mVIBok.setChecked(false);                mVIBfail.setChecked(false);

        new Timer().schedule(new TimerTask() {
            public void run() {
                Intent intent = new Intent(ProtocolConstants.ACTION_CMD_FIRMWAREVERSION);
                sendBroadcast(intent);
            }
        }, 1000);    // execute after 500ms
    }

    /*
    ble device에서 전송된 값은 hex값이지만, byte 배열에 담겨 오므로 변환식 적용을 위해서
    int 배열로 변환한다. byte는 127을 넘어가는 수는 음수로 처리되기 때문.
     */
    private int[] byteArray_to_intArray(byte[] data) {
        int[] int_array = new int[data.length];
        String hexNumber;
        for (int x = 0; x < data.length; x++) {
            hexNumber = "0" + Integer.toHexString(0xff & data[x]);
            int_array[x]=Integer.parseInt(hexNumber, 16);
        }
        return int_array;
    }

    private void send_firmware_cmd() {
        Log.i("KILEE", "send_firmware_cmd()");

        mFirmwareVer.setText("1.0.0");
        mBluetoothValue.setText(" "+mRSSI);
        mBluetoothResult.setTextColor(Color.GREEN);
        mBluetoothResult.setText(" OK");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.FIRMWARE_VER_CMD;
                value[1] = 0x00;
                value[2] = 0x00;
                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }

    private void send_skin1st_cmd() {
        Log.i("KILEE", "send_skin1st_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[5];
                String freq = mSkin_freq.getText().toString();
                Integer freq_int = Integer.parseInt(freq);
                value[0] = TestCommand.SKIN_1ST_CMD;
                value[1] = 0x10;
                value[2] = (byte)freq_int.intValue();
                value[3] = 20;
                value[4] = 10;
                mSkinReturnValue_Freq = value[2];
                Log.i("KILEE", "Freq : " + value[2]);
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_skinnext_cmd() {
        Log.i("KILEE", "send_skinnext_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.SKIN_NEXT_PACKET_CMD;                value[1] = 0x10;    value[2]=0; value[3]=0;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 100);    // execute after 500ms
    }

    private void send_battery_cmd() {
        Log.i("KILEE", "send_battery_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.BATTERY_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }

    private void send_uv_cmd() {
        Log.i("KILEE", "send_uv_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.UV_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_lux_cmd() {
        Log.i("KILEE", "send_lux_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.LUX_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_humidity_cmd() {
        Log.i("KILEE", "send_humidity_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.HUM_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_temperature_cmd() {
        Log.i("KILEE", "send_temperature_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.TEMP_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_accel_cmd() {
        Log.i("KILEE", "send_accel_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.ACCEL_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_serialflash_cmd() {
        Log.i("KILEE", "send_serialflash_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.SERIALFLASH_CMD;                value[1] = 0x00;                value[2] = 0x00;                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }
    private void send_led_cmd() {
        Log.i("KILEE", "send_led_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0]=TestCommand.LED_CMD;  value[1]=0x03;  value[2]=0x03;  value[3]=0x10;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 100);    // execute after 500ms
    }
    private void send_vib_cmd() {
        Log.i("KILEE", "send_vib_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0]=TestCommand.VIB_CMD;  value[1]=0x03;  value[2]=0x03;  value[3]=0x10;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 1000);    // execute after 1000ms
    }

    private void send_poweroff_cmd() {
        Log.i("KILEE", "send_poweroff_cmd()");

        new Timer().schedule(new TimerTask() {
            public void run() {
                byte[] value = new byte[4];
                value[0] = TestCommand.POWER_OFF_CMD;
                value[1] = 0x00;
                value[2] = 0x00;
                value[3] = 0x00;
                mWriteCharacteristic.setValue(value);
                mBluetoothLeService.writeCharacteristic(mWriteCharacteristic);
            }
        }, 500);    // execute after 500ms
    }

    private void rsp_firmware_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);
        mFirmwareVer.setText(data[2] + "." + data[3] + "." + data[4]);  // major, minor, revision

        mMajorVer = data[2];
        mMinorVer = data[3];
        mRevisionVer = data[4];

        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_SKIN_1ST);
        sendBroadcast(nextIntent);
    }

    private void rsp_skin_1st_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        //int[] int_data = byteArray_to_intArray(data);
        int i=0;

        if (data[1]==mSkinReturnValue_Freq) {   // skin data 패킷은 에러없는 경우에 error code로 요청한 주파수값이 온다

            mSkinDataIndex = 0;
            for (i = 0; i < (data.length - 4); i++) {
                //Log.i("KILEE", ""+int_data[i]);
                mSkinData[i + mSkinDataIndex] = data[4 + i];
            }
            mSkinDataIndex = i;

            send_skinnext_cmd();
        }
        else {  // error
            mSkinResult.setTextColor(Color.RED);
            mSkinResult.setText(" FAIL");

            mLogData_BIA.add("FAIL");

            final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_BATTERRY);
            sendBroadcast(nextIntent);
        }
    }
    private void rsp_skin_next_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        //int[] int_data = byteArray_to_intArray(data);
        int i=0;

        if (data[1]==mSkinReturnValue_Freq) {   // skin data 패킷은 에러없는 경우에 error code로 요청한 주파수값이 온다

            for (i = 0; i < (data.length - 4); i++) {
                //Log.i("KILEE", ""+int_data[i]);
                mSkinData[i + mSkinDataIndex] = data[4 + i];
            }
            mSkinDataIndex += i;

            if (mSkinDataIndex >= ProtocolConstants.SKIN_DATA_SIZE) {
                Log.i("KILEE", "Assembling skin data is complete");

                if (isSkinValueClicked) {
                    OpenChart(mSkinData);
                    mLoading.hide();
                } else {
                    check_skin_data();

                    final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_BATTERRY);
                    sendBroadcast(nextIntent);
                }

            } else {
                send_skinnext_cmd();
            }
        }
        else {  // error
            mSkinResult.setTextColor(Color.RED);
            mSkinResult.setText(" FAIL");

            mLogData_BIA.add("FAIL");

            final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_BATTERRY);
            sendBroadcast(nextIntent);
        }
    }

    private void OpenChart(int[] value) {

        Debug.logd(new Exception(), "OpenChart is called... : " + isSkinValueClicked);

        View chartView;

        XYSeries series = new XYSeries("BIA");

        for(int i = 0; i < value.length; i++) {
            series.add(i, value[i]);
        }

        XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();

        dataset.addSeries(series);

        XYSeriesRenderer renderer = new XYSeriesRenderer();
        renderer.setColor(Color.WHITE);
        renderer.setPointStyle(PointStyle.CIRCLE);
        renderer.setFillPoints(true);
        renderer.setLineWidth(2);
        renderer.setDisplayChartValuesDistance(100);
        renderer.setDisplayChartValues(true);

        XYMultipleSeriesRenderer multipleSeriesRenderer = new XYMultipleSeriesRenderer();
        multipleSeriesRenderer.setXLabels(0);
        multipleSeriesRenderer.setChartTitle("Skin Test");
        multipleSeriesRenderer.setXTitle("bytes");
        multipleSeriesRenderer.setYTitle("value");
        multipleSeriesRenderer.setChartTitleTextSize(28);
        multipleSeriesRenderer.setAxisTitleTextSize(24);
        multipleSeriesRenderer.setLabelsTextSize(24);
        multipleSeriesRenderer.setChartValuesTextSize(24);
        multipleSeriesRenderer.setPointSize(2);
        multipleSeriesRenderer.setLegendTextSize(24);
        multipleSeriesRenderer.setShowLegend(true);
        multipleSeriesRenderer.setFitLegend(true);
        multipleSeriesRenderer.setShowGridY(true);
        multipleSeriesRenderer.setShowGridX(true);
        multipleSeriesRenderer.setZoomButtonsVisible(true);
        multipleSeriesRenderer.setBackgroundColor(Color.TRANSPARENT);
        multipleSeriesRenderer.setApplyBackgroundColor(true);

        multipleSeriesRenderer.setMargins(new int[]{50, 50, 25, 22});

        double[] limits = new double[] {0, value.length + 10, 0, 130};
        multipleSeriesRenderer.setPanLimits(limits);
        multipleSeriesRenderer.setZoomLimits(limits);

        multipleSeriesRenderer.setXAxisMin(0);
        multipleSeriesRenderer.setXAxisMax(120);
        multipleSeriesRenderer.setYAxisMin(0);
        multipleSeriesRenderer.setYAxisMax(130);

        for(int i = 0; i < value.length; i++) {
            if(i % 10 == 0) {
                multipleSeriesRenderer.addXTextLabel(i, Integer.toString(i));
            }
        }

        multipleSeriesRenderer.addSeriesRenderer(renderer);

        LinearLayout chartArea = (LinearLayout) findViewById(R.id.chart_area);
        chartArea.removeAllViews();

        chartView = ChartFactory.getLineChartView(this, dataset, multipleSeriesRenderer);
        chartArea.addView(chartView);
    }
    private void check_skin_data() {
        int min_skin_data=0xffff, max_skin_data=0x0000;
        int idx;

        // find min, max
        for (idx=0; idx<mSkinDataIndex; idx++) {
            //Log.i("KILEE", ""+mSkinData[idx]);
            //Debug.logi(new Exception(), "idx : " + idx + ", " + mSkinData[idx]);
            if (min_skin_data > mSkinData[idx]) min_skin_data = mSkinData[idx];
            if (max_skin_data < mSkinData[idx]) max_skin_data = mSkinData[idx];
        }

        mSkinDataIndex=0;
        for(idx=0; idx<mSkinData.length; idx++)   mSkinData[idx]=0;

        mSkinValue.setText(" " + max_skin_data + " " + min_skin_data);
        mSkinResult.setTextColor(Color.GREEN);
        mSkinResult.setText("OK");

        mLogData_BIA.add("OK");
        mLogData_BIA.add(""+max_skin_data);
        mLogData_BIA.add("" + min_skin_data);
    }

    private void rsp_battery_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        int[] int_data = byteArray_to_intArray(data);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+int_data[i]);

        if (int_data[1] == 0){
            mBatteryValue.setText(" " + int_data[2]);
            mBatteryResult.setTextColor(Color.GREEN);
            mBatteryResult.setText(" OK");

            mLogData_BAT.add("OK");
            mLogData_BAT.add("" + int_data[2]);
        }
        else {
            mBatteryResult.setTextColor(Color.RED);
            mBatteryResult.setText(" FAIL");

            mLogData_BAT.add("FAIL");
        }

        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_UV);
        sendBroadcast(nextIntent);
    }
    private void rsp_uv_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        int[] int_data = byteArray_to_intArray(data);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+int_data[i]);

        int uv_ref, uv_range;
        int uv_low, uv_high;
        uv_ref = Integer.parseInt(mUV_ref.getText().toString());
        uv_range = Integer.parseInt(mUV_range.getText().toString());
        uv_low = uv_ref - uv_range;
        uv_high = uv_ref + uv_range;
        if (uv_low<0)   uv_low=0;

        if (int_data[1] == 0){
            int raw_uv = int_data[3] << 8 | int_data[2];
            int transform_uv=raw_uv/100;

            mUVValue.setText(" " + transform_uv);

            if (transform_uv >=uv_low && transform_uv<=uv_high) {
                mUVResult.setTextColor(Color.GREEN);
                mUVResult.setText(" OK");

                mLogData_UV.add("OK");
                mLogData_UV.add("" + transform_uv);
            }
            else {
                mUVResult.setTextColor(Color.RED);
                mUVResult.setText(" FAIL");

                mLogData_UV.add("FAIL");
            }
        }
        else {
            mUVResult.setTextColor(Color.RED);
            mUVResult.setText(" FAIL");

            mLogData_UV.add("FAIL");
        }

        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_LUX);
        sendBroadcast(nextIntent);
    }

    /*
    LUX 변환식
    X = ((ALS - 256) x 5.41) + ((IR - 256) x (-0.08))
    ALS == visible
    */
    private void rsp_lux_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        int[] int_data = byteArray_to_intArray(data);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+int_data[i]);

        int lux_ref, lux_range;
        int lux_low, lux_high;
        lux_ref = Integer.parseInt(mLUX_ref.getText().toString());
        lux_range = Integer.parseInt(mLUX_range.getText().toString());
        lux_low = lux_ref - lux_range;
        lux_high = lux_ref + lux_range;
        if (lux_low<0)   lux_low=0;

        if (int_data[1] == 0){
            int visible = int_data[3] << 8 | int_data[2];
            int ir = int_data[5] << 8 | int_data[4];

            double lux = (visible-256)*5.41 + ((ir-256)*(-0.08));
            if (lux<0)  lux=0;

            String string_lux = String.format("%.1f", lux);
            mLUXValue.setText(" " + string_lux);

            if (lux >=lux_low && lux<=lux_high) {
                mLUXResult.setTextColor(Color.GREEN);
                mLUXResult.setText(" OK");

                mLogData_LUX.add("OK");
                mLogData_LUX.add("" + string_lux + " " + visible + " " + ir);
            }
            else {
                mLUXResult.setTextColor(Color.RED);
                mLUXResult.setText(" FAIL");

                mLogData_LUX.add("FAIL");
            }
        }
        else {
            mLUXResult.setTextColor(Color.RED);
            mLUXResult.setText(" FAIL");

            mLogData_LUX.add("FAIL");
        }
        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_HUM);
        sendBroadcast(nextIntent);
    }

    /*
    습도 변환식
    X = 100.0f * (ft)rawValue / 65535.0f
     */
    private void rsp_humidity_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        int[] int_data = byteArray_to_intArray(data);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+int_data[i]);

        int hum_ref, hum_range;
        int hum_low, hum_high;
        hum_ref = Integer.parseInt(mHUM_ref.getText().toString());
        hum_range = Integer.parseInt(mHUM_range.getText().toString());
        hum_low = hum_ref - hum_range;
        hum_high = hum_ref + hum_range;
        if (hum_low<0)   hum_low=0;

        if (int_data[1] == 0){
            int hum = int_data[3]<<8 | int_data[2];
            double transform_hum = 100.0f * (float)hum / 65535.0f;

            String string_hum = String.format("%.1f", transform_hum);
            mHUMValue.setText(" " + string_hum);

            if (transform_hum >=hum_low && transform_hum<=hum_high) {
                mHUMResult.setTextColor(Color.GREEN);
                mHUMResult.setText(" OK");

                mLogData_HUM.add("OK");
                mLogData_HUM.add("" + string_hum + " " + hum);
            }
            else {
                mHUMResult.setTextColor(Color.RED);
                mHUMResult.setText(" FAIL");

                mLogData_HUM.add("FAIL");
            }
        }
        else {
            mHUMResult.setTextColor(Color.RED);
            mHUMResult.setText(" FAIL");

            mLogData_HUM.add("FAIL");
        }
        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_TEMP);
        sendBroadcast(nextIntent);
    }

    /*
    온도 변환식
    X = 175.0f * (ft)rawValue / 65535.0f - 45.0f
     */
    private void rsp_temperature_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        int[] int_data = byteArray_to_intArray(data);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+int_data[i]);

        int tem_ref, tem_range;
        int tem_low, tem_high;
        tem_ref = Integer.parseInt(mTEMP_ref.getText().toString());
        tem_range = Integer.parseInt(mTEMP_range.getText().toString());
        tem_low = tem_ref - tem_range;
        tem_high = tem_ref + tem_range;
        if (tem_low<0)   tem_low=0;

        if (int_data[1] == 0){
            int temp = int_data[3]<<8 | int_data[2];
            double transform_temp = 175.0f * (float) temp/65535.0f - 45.0f;

            String string_temp = String.format("%.1f", transform_temp);
            mTEMPValue.setText(" " + string_temp);

            if (transform_temp >=tem_low && transform_temp<=tem_high) {
                mTEMPResult.setTextColor(Color.GREEN);
                mTEMPResult.setText(" OK");

                mLogData_TEM.add("OK");
                mLogData_TEM.add("" + string_temp + " " + temp);
            }
            else {
                mTEMPResult.setTextColor(Color.RED);
                mTEMPResult.setText(" FAIL");

                mLogData_TEM.add("FAIL");
            }
        }
        else {
            mTEMPResult.setTextColor(Color.RED);
            mTEMPResult.setText(" FAIL");

            mLogData_TEM.add("FAIL");
        }
        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_ACCEL);
        sendBroadcast(nextIntent);
    }
    private void rsp_accel_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        int[] int_data = byteArray_to_intArray(data);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+int_data[i]);
        if (int_data[1] == 0){
            mACCELValue.setText(" " + int_data[2] + ":" + int_data[3] + ":" + int_data[4]);
            mACCELResult.setTextColor(Color.GREEN);
            mACCELResult.setText(" OK");

            mLogData_ACC.add("OK");
            mLogData_ACC.add("" + int_data[2] + " " + int_data[3] + " " + int_data[4]);
        }
        else {
            mACCELResult.setTextColor(Color.RED);
            mACCELResult.setText(" FAIL");

            mLogData_ACC.add("FAIL");
        }
        final Intent nextIntent = new Intent(ProtocolConstants.ACTION_CMD_SERIALFLASH);
        sendBroadcast(nextIntent);
    }
    private void rsp_serialflash_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);
        if (data[1] == 0){
            mSFResult.setTextColor(Color.GREEN);
            mSFResult.setText(" OK");

            mLogData_SF.add("OK");
        }
        else {
            mSFResult.setTextColor(Color.RED);
            mSFResult.setText(" FAIL");

            mLogData_SF.add("FAIL");
        }
    }
    private void rsp_led_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);


    }
    private void rsp_vib_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);


    }
    private void rsp_button_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);
        mButtonInputResult.setTextColor(Color.GREEN);
        mButtonInputResult.setText("OK");

        mLogData_KEY.add("OK");
    }
    private void rsp_poweroff_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);

        finish();
    }
    private void rsp_gettime_cmd(Intent intent) {
        byte[] data = intent.getExtras().getByteArray(BluetoothLeService.EXTRA_DATA);
        for (int i=0; i<data.length; i++)            Log.i("KILEE", ""+data[i]);

        if (data[1]==0) {
            long get_time = ((data[5]&0xFF)<<24) | ((data[4]&0xFF)<<16) | ((data[3]&0xFF)<<8) |(data[2]&0xFF);
            Log.i("KILEE", "get_time : " + get_time);
            get_time *= 1000;

            // 현재 시간을 저장 한다.
            Date date = new Date(get_time);
            // 시간 포맷 지정

            SimpleDateFormat CurMonthFormat = new SimpleDateFormat("MM");
            SimpleDateFormat CurDayFormat = new SimpleDateFormat("dd");
            SimpleDateFormat CurHourFormat = new SimpleDateFormat("HH");
            SimpleDateFormat CurMinuteFormat = new SimpleDateFormat("mm");
            SimpleDateFormat CurSecondFormat = new SimpleDateFormat("ss");
            String strCurMonth = CurMonthFormat.format(date);
            String strCurDay = CurDayFormat.format(date);
            String strCurHour = CurHourFormat.format(date);
            String strCurMinute = CurMinuteFormat.format(date);
            String strCurSecond = CurSecondFormat.format(date);

//            TextView gettime_label = (TextView) findViewById(R.id.gettime_label_tv);
//            gettime_label.setText(strCurMonth + "_" + strCurDay + "_" + strCurHour + "_" + strCurMinute + "_" + strCurSecond);
        }
    }

    private final BroadcastReceiver mBleTestCommandReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                //updateConnectionState(R.string.connected);
                //invalidateOptionsMenu();
                Log.i ("KILEE", "BR-ACTION_GATT_CONNECTED");

            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                //updateConnectionState(R.string.disconnected);
                //invalidateOptionsMenu();
                //clearUI();
                Log.i ("KILEE", "BR-ACTION_GATT_DISCONNECTED");
                mDialog.hide();
                finish();

            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                // Show all the supported services and characteristics on the user interface.
                //displayGattServices(mBluetoothLeService.getSupportedGattServices());
                getGattServices(mBluetoothLeService.getSupportedGattServices());

                Log.i ("KILEE", "BR-ACTION_GATT_SERVICES_DISCOVERED");

            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                //displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
            }

            else if (ProtocolConstants.ACTION_CMD_FIRMWAREVERSION.equals(action))
                send_firmware_cmd();
            else if (ProtocolConstants.ACTION_CMD_SKIN_1ST.equals(action))
                send_skin1st_cmd();
            else if (ProtocolConstants.ACTION_CMD_SKIN_NEXT.equals(action))
                send_skinnext_cmd();
            else if (ProtocolConstants.ACTION_CMD_BATTERRY.equals(action))
                send_battery_cmd();
            else if (ProtocolConstants.ACTION_CMD_UV.equals(action))
                send_uv_cmd();
            else if (ProtocolConstants.ACTION_CMD_LUX.equals(action))
                send_lux_cmd();
            else if (ProtocolConstants.ACTION_CMD_HUM.equals(action))
                send_humidity_cmd();
            else if (ProtocolConstants.ACTION_CMD_TEMP.equals(action))
                send_temperature_cmd();
            else if (ProtocolConstants.ACTION_CMD_ACCEL.equals(action))
                send_accel_cmd();
            else if (ProtocolConstants.ACTION_CMD_SERIALFLASH.equals(action))
                send_serialflash_cmd();
            else if (ProtocolConstants.ACTION_CMD_LED.equals(action))
                send_led_cmd();
            else if (ProtocolConstants.ACTION_CMD_VIB.equals(action))
                send_vib_cmd();
            else if (ProtocolConstants.ACTION_CMD_POWEROFF.equals(action))
                send_poweroff_cmd();

            else if (ProtocolConstants.ACTION_RSP_FIRMWAREVERSION.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_FIRMWAREVERSION");
                rsp_firmware_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_SKIN_1ST.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_SKIN_1ST");
                rsp_skin_1st_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_SKIN_NEXT.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_SKIN_NEXT");
                rsp_skin_next_cmd(intent);
            }

            else if (ProtocolConstants.ACTION_RSP_BATTERRY.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_BATTERRY");
                rsp_battery_cmd(intent);
            }

            else if (ProtocolConstants.ACTION_RSP_UV.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_UV");
                rsp_uv_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_LUX.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_LUX");
                rsp_lux_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_HUM.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_HUM");
                rsp_humidity_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_TEMP.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_TEMP");
                rsp_temperature_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_ACCEL.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_ACCEL");
                rsp_accel_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_SERIALFLASH.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_SERIALFLASH");
                rsp_serialflash_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_LED.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_LED");
                rsp_led_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_VIB.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_VIB");
                rsp_vib_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_BUTTON.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_BUTTON");
                rsp_button_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_POWEROFF.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_POWEROFF");
                rsp_poweroff_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_RSP_GETTIME.equals(action)) {
                Log.i("KILEE", "ACTION_RSP_GETTIME");
                rsp_gettime_cmd(intent);
            }
            else if (ProtocolConstants.ACTION_CMD_BLUETOOTH_FAIL.equals(action)) {
                String errorMsg = intent.getStringExtra(BluetoothLeService.EXTRA_DATA);
                Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
            }
            else {}
        }
    };

    private void getGattServices (List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        String uuid = null;
        String unknownServiceString = getResources().getString(R.string.unknown_service);
        String unknownCharaString = getResources().getString(R.string.unknown_characteristic);
        ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<HashMap<String, String>>();
        ArrayList<ArrayList<HashMap<String, String>>> gattCharacteristicData
                = new ArrayList<ArrayList<HashMap<String, String>>>();
        mGattCharacteristics = new ArrayList<ArrayList<BluetoothGattCharacteristic>>();

        UUID UUID_IMPEDANCE_SERVICE = UUID.fromString(TestGattAttributes.IMPEDANCE_SERVICE);
        UUID UUID_IMPEDANCE_NOTIFY = UUID.fromString(TestGattAttributes.IMPEDANCE_NOTIFY);

        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {

//            Log.d("KILEE", "==============================");
//            Log.d("KILEE", "Service loop");
//            Log.d("KILEE", "UUID : " + gattService.getUuid().toString());

            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();
            currentServiceData.put(LIST_NAME, TestGattAttributes.lookup(uuid, unknownServiceString));
            currentServiceData.put(LIST_UUID, uuid);
            gattServiceData.add(currentServiceData);

            if (uuid.equals(TestGattAttributes.IMPEDANCE_SERVICE))
            {
                Log.i("KILEE", "Find IMPEDANCE SERVICE");
            }

            ArrayList<HashMap<String, String>> gattCharacteristicGroupData =new ArrayList<HashMap<String, String>>();
            List<BluetoothGattCharacteristic> gattCharacteristics =gattService.getCharacteristics();
            ArrayList<BluetoothGattCharacteristic> charas =new ArrayList<BluetoothGattCharacteristic>();

            // Loops through available Characteristics.
            for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {

//                Log.d("KILEE", "==============================");
//                Log.d("KILEE", "Characteristic loop");
//                Log.d("KILEE", "UUID : " + gattCharacteristic.getUuid().toString());

                if (gattCharacteristic.getUuid().toString().equals(TestGattAttributes.IMPEDANCE_NOTIFY))
                {
                    Log.i("KILEE", "Find IMPEDANCE NOTIFY");
                    final int charaProp = gattCharacteristic.getProperties();
                    if ((charaProp & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0)
                    {
                        Log.d("KILEE", "NOTIFY UUID : " + gattCharacteristic.getUuid().toString());

                        if (mNotifyCharacteristic != null) {
                            mBluetoothLeService.setCharacteristicNotification(mNotifyCharacteristic, false);
                            mNotifyCharacteristic = null;
                        }
                        else
                        {
                            mNotifyCharacteristic = gattCharacteristic;
                            mBluetoothLeService.setCharacteristicNotification(gattCharacteristic, true);
                        }
                    }
                }
                else if(gattCharacteristic.getUuid().toString().equals(TestGattAttributes.IMPEDANCE_WRITE))
                {
                    Log.i("KILEE", "Find IMPEDANCE WRITE");
                    mWriteCharacteristic = gattCharacteristic;
                }

                charas.add(gattCharacteristic);
                HashMap<String, String> currentCharaData = new HashMap<String, String>();
                uuid = gattCharacteristic.getUuid().toString();

                int charaProp = gattCharacteristic.getProperties();
//                Log.d("KILEE", "getProperties() : " + Integer.toHexString(charaProp));

                currentCharaData.put(LIST_NAME, TestGattAttributes.lookup(uuid, unknownCharaString));
                currentCharaData.put(LIST_UUID, uuid);
                gattCharacteristicGroupData.add(currentCharaData);
            }
            mGattCharacteristics.add(charas);
            gattCharacteristicData.add(gattCharacteristicGroupData);
        }

        // notify, write characteristic 모두 찾으면 첫번째 명령(FIRMWAREVERSION)을 보낸다.
        if (mNotifyCharacteristic != null && mNotifyCharacteristic != null) {
            final Intent intent = new Intent(ProtocolConstants.ACTION_CMD_FIRMWAREVERSION);
            sendBroadcast(intent);
            mDialog.hide();
        }
    }

    private void make_and_save_logfile() {
        String[] device_mac = mDeviceAddress.split(":");
        int device_mac_count = device_mac.length;

        String result_string="ok";
        assemble_logdata();

        for(int i=0; i<ProtocolConstants.LOGDATA_COUNT; i++) {
            ArrayList<String> item = mLogData_ALL.get(i);
            if (item.size() > 1) {
                String ok_or_fail = item.get(1);
                //Log.i("KILEE", "ok_or_fail : " + ok_or_fail);
                if (!ok_or_fail.equals("OK"))
                {
                    Log.i("KILEE", "i : " + i);
                    result_string="fail";
                    break;
                }
            }
            else {
                result_string="fail";
                break;
            }
        }


        long now = System.currentTimeMillis();

        // 현재 시간을 저장 한다.
        Date date = new Date(now);
        // 시간 포맷 지정

        SimpleDateFormat CurDateFormat = new SimpleDateFormat("yyMMdd");
        SimpleDateFormat CurtimeFormat = new SimpleDateFormat("HHmmss");
        mLogFilePath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator;
        mLogFilePath += "Way_" + mMajorVer + "_" + mMinorVer + "_" + mRevisionVer + "_" + CurDateFormat.format(date) + "_" + CurtimeFormat.format(date) + "_" +
                device_mac[device_mac_count-3] + device_mac[device_mac_count-2] + device_mac[device_mac_count-1] + "_" + result_string + ".log";

        try {
            BufferedWriter buw = new BufferedWriter(new FileWriter(mLogFilePath, true));
            buw.write(mLogFilePath);
            buw.newLine();buw.newLine();

            for(int i=0; i<ProtocolConstants.LOGDATA_COUNT; i++) {
                ArrayList<String> item = mLogData_ALL.get(i);
                for (int k=0; k<item.size(); k++) {
                    buw.write(item.get(k));
                    buw.write(" ");
                }
                buw.newLine();
            }
            buw.close();
        } catch (IOException e) {}
    }

    private void initializeLogData() {
        mLogData_ALL = new ArrayList<ArrayList<String>>();
        mLogData_BT=new ArrayList<String>();
        mLogData_BT.add("BT");

        mLogData_BIA=new ArrayList<String>();
        mLogData_BIA.add("BIA");

        mLogData_BAT=new ArrayList<String>();
        mLogData_BAT.add("BAT");

        mLogData_UV=new ArrayList<String>();
        mLogData_UV.add("UV");

        mLogData_LUX=new ArrayList<String>();
        mLogData_LUX.add("LUX");

        mLogData_HUM=new ArrayList<String>();
        mLogData_HUM.add("HUM");

        mLogData_TEM=new ArrayList<String>();
        mLogData_TEM.add("TEM");

        mLogData_ACC=new ArrayList<String>();
        mLogData_ACC.add("ACC");

        mLogData_SF=new ArrayList<String>();
        mLogData_SF.add("SF");

        mLogData_LED=new ArrayList<String>();
        mLogData_LED.add("LED");

        mLogData_VIB=new ArrayList<String>();
        mLogData_VIB.add("VIB");

        mLogData_KEY=new ArrayList<String>();
        mLogData_KEY.add("KEY");
    }

    private void assemble_logdata() {
        mLogData_ALL.add(mLogData_BT);
        mLogData_ALL.add(mLogData_BIA);
        mLogData_ALL.add(mLogData_BAT);
        mLogData_ALL.add(mLogData_UV);
        mLogData_ALL.add(mLogData_LUX);
        mLogData_ALL.add(mLogData_HUM);
        mLogData_ALL.add(mLogData_TEM);
        mLogData_ALL.add(mLogData_ACC);
        mLogData_ALL.add(mLogData_SF);
        mLogData_ALL.add(mLogData_LED);
        mLogData_ALL.add(mLogData_VIB);
        mLogData_ALL.add(mLogData_KEY);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("KILEE", "onResume()");
        registerReceiver(mBleTestCommandReceiver, makeBleTestCommandIntentFilter());
        if (mBluetoothLeService != null) {
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }
    }

    private static IntentFilter makeBleTestCommandIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);

        intentFilter.addAction(ProtocolConstants.ACTION_CMD_FIRMWAREVERSION);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_SKIN_1ST);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_SKIN_NEXT);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_BATTERRY);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_UV);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_LUX);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_HUM);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_TEMP);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_ACCEL);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_SERIALFLASH);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_BUTTON);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_LED);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_VIB);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_POWEROFF);
        intentFilter.addAction(ProtocolConstants.ACTION_CMD_GETTIME);

        intentFilter.addAction(ProtocolConstants.ACTION_RSP_FIRMWAREVERSION);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_SKIN_1ST);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_SKIN_NEXT);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_BATTERRY);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_UV);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_LUX);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_HUM);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_TEMP);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_ACCEL);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_SERIALFLASH);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_BUTTON);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_LED);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_VIB);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_POWEROFF);
        intentFilter.addAction(ProtocolConstants.ACTION_RSP_GETTIME);

        intentFilter.addAction(ProtocolConstants.ACTION_CMD_BLUETOOTH_FAIL);

        return intentFilter;
    }

    @Override
    protected void onPause() {
        super.onPause();
//        unregisterReceiver(mBleTestCommandReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("KILEE", "onDestroy");
        unregisterReceiver(mBleTestCommandReceiver);    // back button 눌린 경우와  finish() 가 호출된 두 경우 모두 실행됨
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }

}