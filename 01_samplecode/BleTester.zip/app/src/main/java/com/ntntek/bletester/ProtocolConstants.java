package com.ntntek.bletester;

/**
 * Created by Administrator on 2015-08-17.
 */
public class ProtocolConstants {

    public static final String FILTERING_STRING_WAY="WAY";

    // Preference에 사용될 Key값
    public static final String SENSOR_PREF="SENSOR_PREF";
    public static final String KEY_SKIN_REF="KEY_SKIN_REF";
    public static final String KEY_UV_REF="KEY_UV_REF";
    public static final String KEY_UV_RANGE="KEY_UV_RANGE";
    public static final String KEY_LUX_REF="KEY_LUX_REF";
    public static final String KEY_LUX_RANGE="KEY_LUX_RANGE";
    public static final String KEY_HUM_REF="KEY_HUM_REF";
    public static final String KEY_HUM_RANGE="KEY_HUM_RANGE";
    public static final String KEY_TEM_REF="KEY_TEM_REF";
    public static final String KEY_TEM_RANGE="KEY_TEM_RANGE";

    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";
    public static final String EXTRAS_DEVICE_RSSI = "DEVICE_RSSI";

    public static int SKIN_DATA_SIZE=600;

    public static int LOGDATA_COUNT=12;
    public static int LOGDATA_BT=0;
    public static int LOGDATA_BIA=1;
    public static int LOGDATA_BAT=2;
    public static int LOGDATA_UV=3;
    public static int LOGDATA_LUX=4;
    public static int LOGDATA_HUM=5;
    public static int LOGDATA_TEM=6;
    public static int LOGDATA_ACC=7;
    public static int LOGDATA_SF=8;
    public static int LOGDATA_LED=9;
    public static int LOGDATA_VIB=10;
    public static int LOGDATA_KEY=11;


    // error or write fail
    public final static String ACTION_CMD_BLUETOOTH_FAIL="ACTION_CMD_BLUETOOTH_FAIL";

    // command
    public final static String ACTION_CMD_FIRMWAREVERSION ="ACTION_CMD_FIRMWAREVERSION";
    public final static String ACTION_CMD_SKIN_1ST ="ACTION_CMD_SKIN_1ST";
    public final static String ACTION_CMD_SKIN_NEXT ="ACTION_CMD_SKIN_NEXT";
    public final static String ACTION_CMD_BATTERRY ="ACTION_CMD_BATTERRY";
    public final static String ACTION_CMD_UV="ACTION_CMD_UV";
    public final static String ACTION_CMD_LUX ="ACTION_CMD_LUX";
    public final static String ACTION_CMD_HUM ="ACTION_CMD_HUM";
    public final static String ACTION_CMD_TEMP ="ACTION_CMD_TEMP";
    public final static String ACTION_CMD_ACCEL ="ACTION_CMD_ACCEL";
    public final static String ACTION_CMD_SERIALFLASH ="ACTION_CMD_SERIALFLASH";
    public final static String ACTION_CMD_BUTTON ="ACTION_CMD_BUTTON";  // 디바이스에서 버튼이 눌렸을때 해당 값이 올라옴. UVIndex, Humidity(%), Temperature
    public final static String ACTION_CMD_LED ="ACTION_CMD_LED";
    public final static String ACTION_CMD_VIB ="ACTION_CMD_VIB";
    public final static String ACTION_CMD_POWEROFF ="ACTION_CMD_POWEROFF";
    public final static String ACTION_CMD_GETTIME ="ACTION_CMD_GETTIME";

    // response
    public final static String ACTION_RSP_FIRMWAREVERSION ="ACTION_RST_FIRMWAREVERSION";
    public final static String ACTION_RSP_SKIN_1ST ="ACTION_RSP_SKIN_1ST";
    public final static String ACTION_RSP_SKIN_NEXT ="ACTION_RSP_SKIN_NEXT";
    public final static String ACTION_RSP_BATTERRY ="ACTION_RST_BATTERRY";
    public final static String ACTION_RSP_UV="ACTION_RSP_UV";
    public final static String ACTION_RSP_LUX ="ACTION_RSP_LUX";
    public final static String ACTION_RSP_HUM ="ACTION_RSP_HUM";
    public final static String ACTION_RSP_TEMP ="ACTION_RSP_TEMP";
    public final static String ACTION_RSP_ACCEL ="ACTION_RSP_ACCEL";
    public final static String ACTION_RSP_SERIALFLASH ="ACTION_RSP_SF";
    public final static String ACTION_RSP_BUTTON ="ACTION_RSP_BUTTON";
    public final static String ACTION_RSP_LED ="ACTION_RSP_LED";
    public final static String ACTION_RSP_VIB ="ACTION_RSP_VIB";
    public final static String ACTION_RSP_POWEROFF ="ACTION_RSP_POWEROFF";
    public final static String ACTION_RSP_GETTIME ="ACTION_RSP_GETTIME";
}
