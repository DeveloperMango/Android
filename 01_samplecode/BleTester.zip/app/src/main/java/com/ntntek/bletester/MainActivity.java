package com.ntntek.bletester;


import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Activity for scanning and displaying available Bluetooth LE devices.
 */
public class MainActivity extends Activity {
    EditText mInputRSSI;
    int mRSSI_threshold;
    String mRSSI_string;
    String mDefaultRSSI_string="-100";

    private ListView mScanListView;
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private Handler mHandler;

    private static final int REQUEST_ENABLE_BT = 1;
    // Stops scanning after 10 seconds.
    private static final long SCAN_PERIOD = 10000;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActionBar().setTitle(R.string.app_name);
        setContentView(R.layout.activity_main);

        // always turns on
        int flags = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON;
        getWindow().addFlags(flags);

        mHandler = new Handler();

        // Use this check to determine whether BLE is supported on the device.  Then you can
        // selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
        }

        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Ensures Bluetooth is enabled on the device.  If Bluetooth is not currently enabled,
        // fire an intent to display a dialog asking the user to grant permission to enable it.
        if (!mBluetoothAdapter.isEnabled()) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }

        mInputRSSI = (EditText) findViewById(R.id.rssi_et);
        mRSSI_string = mDefaultRSSI_string;
        mInputRSSI.setText(mRSSI_string);
        mInputRSSI.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s != null) {
                    //Log.i("KILEE", s + " start : " + start + "  before : " + before + "   count : " + count);
                    if (s.length() > 1){
                        char first_char = s.charAt(0);
                        char second_char = s.charAt(1);

                        // - 부호 다음에 0 문자를 입력하면 - 입력으로 강제 변경한다
                        if (first_char == '-' && second_char == '0') {
                            String minus_string = "-";
                            mInputRSSI.setText(minus_string);
                            mInputRSSI.setSelection(mInputRSSI.length());   // 커서를 끝에 위치시킴
                        }
                    }
                    else if (s.length() >0)
                    {
                        char first_char = s.charAt(0);
                        if (first_char == '0')  mInputRSSI.setText(null);   // 입력 초기화
                    }
                }
            }
            @Override
            public void afterTextChanged(Editable s) {            }
        });

        // Initializes list view adapter.
        mLeDeviceListAdapter = new LeDeviceListAdapter();
        mScanListView = (ListView) findViewById(R.id.scan_list);
        mScanListView.setAdapter(mLeDeviceListAdapter);
        mScanListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {

                check_and_get_RSSI();

                final BluetoothDevice device = mLeDeviceListAdapter.getDevice(position);
                if (device == null) return;

                final Intent intent = new Intent(MainActivity.this, TestDeviceActivity.class);
                String rssi = mLeDeviceListAdapter.getRSSI(position).toString();
                intent.putExtra(ProtocolConstants.EXTRAS_DEVICE_NAME, device.getName());
                intent.putExtra(ProtocolConstants.EXTRAS_DEVICE_ADDRESS, device.getAddress());
                intent.putExtra(ProtocolConstants.EXTRAS_DEVICE_RSSI, rssi);
                Log.i("KILEE", "RSSI [" + position + "] : " + rssi);

                if (mScanning) {
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    mScanning = false;
                }
                startActivity(intent);
            }
        });

        RelativeLayout root_layout=(RelativeLayout)findViewById(R.id.scanlist_layout);
        root_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_and_get_RSSI();
            }
        });
    }

    // 입력받은 RSSI 값에 대한 유효성 검사 및 키보드 내리기. RSSI 문자열 가져오기
    public void check_and_get_RSSI() {
        checkRSSIValue();
        hideRSSIKeyboard(); // 레이아웃의 키보드 내리기
        mRSSI_string = mInputRSSI.getText().toString();
    }

    public void checkRSSIValue() {
        // - 만 입력하고 키보드를 내리면 기본값으로 복원
        mRSSI_string = mInputRSSI.getText().toString();
        String minus_string="-";
        if (mRSSI_string.equals(minus_string)) {
            mRSSI_string = mDefaultRSSI_string;
            mInputRSSI.setText(mRSSI_string);
            mInputRSSI.setSelection(mInputRSSI.length());
        }
    }

    public void hideRSSIKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mInputRSSI.getWindowToken(), 0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        if (!mScanning) {
            menu.findItem(R.id.menu_stop).setVisible(false);
            menu.findItem(R.id.menu_scan).setVisible(true);
            menu.findItem(R.id.menu_refresh).setActionView(null);
        } else {
            menu.findItem(R.id.menu_stop).setVisible(true);
            menu.findItem(R.id.menu_scan).setVisible(false);
            menu.findItem(R.id.menu_refresh).setActionView(
                    R.layout.actionbar_indeterminate_progress);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        check_and_get_RSSI();

        switch (item.getItemId()) {
            case R.id.menu_scan:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mLeDeviceListAdapter.clear();
                        mLeDeviceListAdapter.notifyDataSetChanged();
                    }
                });
                scanLeDevice(true);
                break;
            case R.id.menu_stop:
                scanLeDevice(false);
                break;
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        scanLeDevice(true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // User chose not to enable Bluetooth.
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            finish();
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        scanLeDevice(false);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mLeDeviceListAdapter.clear();
                mLeDeviceListAdapter.notifyDataSetChanged();
            }
        });
    }

    private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;
            mBluetoothAdapter.startLeScan(mLeScanCallback);
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
        invalidateOptionsMenu();    // destroy all menu and re-call onCreateOptionsMenu
    }

    // Adapter for holding devices found through scanning.
    private class LeDeviceListAdapter extends BaseAdapter {
        private ArrayList<BluetoothDevice> mLeDevices;
        private ArrayList<Integer> mRSSIs;
        private LayoutInflater mInflator;

        public LeDeviceListAdapter() {
            super();
            mLeDevices = new ArrayList<BluetoothDevice>();
            mRSSIs = new ArrayList<Integer>();
            mInflator = MainActivity.this.getLayoutInflater();
        }

        public void addDevice(BluetoothDevice device, int rssi) {
            if(!mLeDevices.contains(device)) {
                mLeDevices.add(device);
                Integer value = Integer.valueOf(rssi);
                mRSSIs.add(value);
                Log.i("KILEE", "addDevice - RSSI : " + rssi);
            }
        }

        public BluetoothDevice getDevice(int position) {
            return mLeDevices.get(position);
        }

        public Integer getRSSI(int position) {
            return mRSSIs.get(position);
        }

        public void clear() {
            mLeDevices.clear();
            mRSSIs.clear();
        }

        @Override
        public int getCount() {
            return mLeDevices.size();
        }

        @Override
        public Object getItem(int i) {
            return mLeDevices.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            // General ListView optimization code.
            if (view == null) {
                view = mInflator.inflate(R.layout.listitem_device, null);
                viewHolder = new ViewHolder();
                viewHolder.deviceAddress = (TextView) view.findViewById(R.id.device_address);
                viewHolder.deviceName = (TextView) view.findViewById(R.id.device_name);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            BluetoothDevice device = mLeDevices.get(i);
            final String deviceName = device.getName();
            if (deviceName != null && deviceName.length() > 0)
                viewHolder.deviceName.setText(deviceName);
            else
                viewHolder.deviceName.setText(R.string.unknown_device);
            viewHolder.deviceAddress.setText(device.getAddress());

            return view;
        }
    }

    private boolean check_device_name(String deviceName) {
        boolean bCheck=false;
        String subString = deviceName.toUpperCase();

        if (deviceName.length() >=3) {
            subString = subString.substring(0, 3);  // 0 과 3 인덱스 사이의 문자열을 반화함
            Log.i("KILEE", "length: " + deviceName.length() + "   " + subString);

            if (subString.equals(ProtocolConstants.FILTERING_STRING_WAY))   // WAY 로 시작하면 true
                bCheck = true;
        }

        return bCheck;
    }

    // Device scan callback.
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback()
            {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord)
                {
                    final int inner_rssi = rssi;
                    if (!check_device_name(device.getName()))   return;

                    if (mRSSI_string==null)
                        mRSSI_threshold=Integer.parseInt(mDefaultRSSI_string);
                    else
                        mRSSI_threshold=Integer.parseInt(mRSSI_string);

                    if (inner_rssi < mRSSI_threshold)    return;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //mLeDeviceListAdapter.addDevice(device);
                            mLeDeviceListAdapter.addDevice(device, inner_rssi);
                            mLeDeviceListAdapter.notifyDataSetChanged();
                        }
                    });
                }
            };

    static class ViewHolder {
        TextView deviceName;
        TextView deviceAddress;
    }
}