package com.ntntek.bletester;

/**
 * Created by Administrator on 2015-08-24.
 */
public class TestCommand {
    static byte SKIN_SINGLE_CMD=0x10;
    static byte SKIN_1ST_CMD=0x11;
    static byte SKIN_NEXT_PACKET_CMD=0x12;

    static byte SET_TIME_CMD=0x20;
    static byte GET_TIME_CMD=0x21;

    static byte UV_CMD=0x31;
    static byte LUX_CMD=0x32;
    static byte HUM_CMD=0x33;
    static byte TEMP_CMD=0x34;
    static byte ACCEL_CMD=0x35;
    static byte LED_CMD=0x41;
    static byte VIB_CMD=0x42;

    static byte BATTERY_CMD=0x60;
    static byte FIRMWARE_VER_CMD=0x61;
    static byte SERIALFLASH_CMD=0x6A;
    static byte POWER_OFF_CMD=0x6B;
    static byte BUTTON_NOTIFICATION=0x70;
}
