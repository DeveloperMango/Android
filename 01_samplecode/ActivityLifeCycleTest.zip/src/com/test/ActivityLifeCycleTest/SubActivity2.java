package com.test.ActivityLifeCycleTest;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

public class SubActivity2 extends Activity 
{
	private static final String TAG = "SubActivity";
	
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
    			WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
        
        setContentView(R.layout.sub2);
        
        Log.i(TAG, "onCreate(Bundle)");
    }
}

