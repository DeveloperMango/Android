package com.test.ActivityLifeCycleTest;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class ActivityLifeCycleTest extends Activity 
{
	private static final String TAG = "ActivityLifeCycleTest";
	
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Log.i(TAG, "onCreate(Bundle)");
    }
    
    @Override
    public void onStart() { super.onStart();  Log.i(TAG, "onStart() "); }
    
    @Override
    public void onResume() { super.onResume(); Log.i(TAG, "onResume()"); }
        
    @Override
    public void onRestart() { super.onRestart(); Log.i(TAG, "onRestart()"); }   
    
    @Override
    public void onPause() { super.onPause(); Log.i(TAG, "onPause()"); }
    
    @Override
    public void onStop() { super.onStop(); Log.i(TAG, "onStop()"); }
    
    @Override
    public void onDestroy() { super.onDestroy(); Log.i(TAG, "onDestroy()"); }   
    
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) 
    {
    	super.onRestoreInstanceState(savedInstanceState);
    	Log.i(TAG, "onRestoreInstanceState(Bundle)");
    }
    
    @Override
    protected void onSaveInstanceState(Bundle b) {
    	super.onSaveInstanceState(b);
    	Log.i(TAG, "onSaveInstanceState(Bundle)");
    }
    
    public void onClick(View v)
    {
    	switch(v.getId())
    	{
    		case R.id.button1:
    			startActivity(new Intent(this, SubActivity.class));
    			break;

    		case R.id.button2:
    			startActivity(new Intent(this, SubActivity2.class));
    			break;
    	}
    }
}

