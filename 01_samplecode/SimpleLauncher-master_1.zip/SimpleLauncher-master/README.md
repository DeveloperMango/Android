# HayaiLauncher

It is a fast, lightweight Android Launcher.
It is [free/libre software](https://www.fsf.org/blogs/rms/20140407-geneva-tedx-talk-free-software-free-society).

The app has a very small APK size and currently requires no permissions.

## Download

- [Google Play Store](https://play.google.com/store/apps/details?id=com.hayaisoftware.launcher)
- [F-Droid](https://f-droid.org/repository/browse/?fdid=com.hayaisoftware.launcher)
- [GitHub](https://github.com/seizonsenryaku/HayaiLauncher/releases)


## Screenshots

<img width="30%" src="https://github.com/seizonsenryaku/HayaiLauncher/raw/master/screenshots/ss1.png" alt="" />
<img width="30%" src="https://github.com/seizonsenryaku/HayaiLauncher/raw/master/screenshots/ss2.png" alt="" />
<img width="30%" src="https://github.com/seizonsenryaku/HayaiLauncher/raw/master/screenshots/ss3.png" alt="" />
